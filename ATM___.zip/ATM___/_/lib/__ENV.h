struct __ENV_BUFFER{

    char * EXC_L_TLT_BUFFER; /*Exceed lenght TLT*/ 

    char * EXC_L_CRE_BUFFER; /*Exceed lenght TLT*/ 

    char * SYS_AT_BUFFER; /*Sys prompt */

    char * ACC_PRT_BUFFER; /*Account name prompt */

    char * CRE_PRT_BUFFER; /*Password account prompt */

    char * CRE_PRT_FORMATED_BUFFER; /*Password account prompt formatted*/

    char * ERR_ALR_EX_BUFFER; /*Error account already exist*/

    char * SUC_ACC_CRE_BUFFER; /* Success account created */

    char * EXC_ACC_CNT; /*Exceed number of account creation*/

};

char * __ENV_BUFF(int BUF_COD){

    struct __ENV_BUFFER sys;

    sys.SYS_AT_BUFFER           = "%sroot? ";

    sys.EXC_L_TLT_BUFFER        = "--root?EXCEED LENGHT **TLT**\n";

    sys.EXC_L_CRE_BUFFER        = "--root?EXCEED LENGHT **CRED**\n";

    sys.ACC_PRT_BUFFER          = "--root?tlt-acc :";

    sys.CRE_PRT_BUFFER          = "--root?cred-acc:";

    sys.ERR_ALR_EX_BUFFER       = "%s--root?ATM ACCOUNT **ALREADY EXIST**\n";

    sys.SUC_ACC_CRE_BUFFER      = "%s--root?ATM ACCOUNT **CREATED**\n";

    sys.EXC_ACC_CNT             = "%s--root?CAN'T CREATE MORE THAN 1 **ACCOUNT**\n";

    sys.CRE_PRT_FORMATED_BUFFER ="--root?cred-acc :";

    if(BUF_COD == 0){

        return sys.SYS_AT_BUFFER;
        
    }else if(BUF_COD == 1){

        return sys.ACC_PRT_BUFFER;

    }else if(BUF_COD == 2){

        return sys.EXC_L_TLT_BUFFER;

    }else if(BUF_COD == 3){

        return sys.CRE_PRT_BUFFER;

    }else if(BUF_COD ==4){

        return sys.EXC_L_CRE_BUFFER;

    }else if(BUF_COD == 5){

        return sys.CRE_PRT_FORMATED_BUFFER;

    }else if(BUF_COD == 6){

        return sys.ERR_ALR_EX_BUFFER;

    }else if(BUF_COD == 7){

        return sys.SUC_ACC_CRE_BUFFER;

    }else if(BUF_COD ==8){
        
        return sys.EXC_ACC_CNT;
    }
}