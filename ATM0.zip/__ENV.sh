#!/bin/bash

#LOADING SYSTEM BANK ATM
nohup python __ENV.py &

{
    for ((i = 0 ; i <= 100 ; i+=5)); do
        sleep 0.02
        echo $i
    done
} | whiptail --gauge "RUNNING THE ATM SERVICE..." 6 50 0


#ASK PASSWORD

PASSWORD=$(whiptail --passwordbox "Enter The Admin Atm Access Password" 8 78 --title "ATM ACCESS PIN" 3>&1 1>&2 2>&3)
exitstatus=$?
if [ $exitstatus == 0 ]; then
    echo "User selected Ok and entered " $PASSWORD
else
    echo "User selected Cancel."
fi

echo "(Exit status was $exitstatus)"

MENU=$(whiptail --title "BANKY" --menu "WHICH TRANSACTION YOU NEED TO MAKE?" 18 58 10 \
"NEW    USER" "  -------------Create An Account" \
"DELETE USER" "  -------------Delete An Account" \
"BLOCK"       "  -------------Block  An Account" \
"TRANSACTION" "  -------------------Transaction" \
"BALANCE"     "  Show the balance of An Account" \
"DEPOSIT"     "  ------Put Funds In The Account" \
"WITHDRAW"    "  -Withdraw Funds In The Account" \
"TRANSFER"    "  -----Transfer Funds to Account" \
"WARNING"     "  ---------Show Rules Of The ATM" \
"REPORT"      "  --Report An Error From The ATM" 3>&1 1>&2 2>&3)











