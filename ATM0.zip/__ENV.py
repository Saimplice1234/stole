from playsound import playsound

playsound('./misc/1.mp3')
